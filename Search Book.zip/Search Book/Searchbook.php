<?php
    include '../Essential Kits/php/conn.php';
    include "../Essential Kits/php/session.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include '../Essential Kits/php/Metadata.php'; ?>
    <link rel="stylesheet" href="../Essential Kits/css/Navbar.css">
    <link rel="stylesheet" href="Searchbook-style.css">
    <title>Search Books</title>
</head>

<body>
    <?php
        include '../Essential Kits/php/Navbar.php';
    ?>
    <div id="main-section">
        <div id="search-engine">
            <form method="get" id="search-engine-searchbox">
                <div id="searchicon"><span class="fa-solid fa-magnifying-glass"></span></div>
                <div id="searchfield-content">
                    <input type="search" name="s" id="searchfield" placeholder="Search any books you want..." autocomplete="off">
                    <ul id="autocomplete"></ul>
                </div>
                <button type="submit" name="b" id="searchbtn" value="search"><span class="fa-solid fa-magnifying-glass"></span><p>Search</p></button>
            </form>
        </div>
        <div id="available-books">
            <?php
                $q="select * from books where Status='Available' order by Title";    //A function will generate this link
                $booksdata = mysqli_query($conn,$q);
                if(mysqli_num_rows($booksdata) > 0) {
                    $i=1;
            ?>
            <table id="search-table">
                <tr class="table-heading">
                    <td class="table-data">S. No.</td>
                    <td class="table-data">Acc. No.</td>
                    <td class="table-data">Title of Book</td>
                    <td class="table-data">Author</td>
                    <td class="table-data">Publisher</td>
                    <td class="table-data">Edition</td>
                </tr>
                <?php
                    while($bookinfo = mysqli_fetch_array($booksdata)) {
                ?>
                <tr class="table-row">
                    <td class="table-data"><?php echo $i."."; $i++; ?></td>
                    <td class="table-data"><?php echo $bookinfo['AccNo'] ?></td>
                    <td class="table-data"><?php echo $bookinfo['Title'] ?></td>
                    <td class="table-data"><?php echo $bookinfo['Author'] ?></td>
                    <td class="table-data"><?php echo $bookinfo['Publisher'] ?></td>
                    <td class="table-data"><?php echo $bookinfo['Edition'] ?></td>
                </tr>
                <?php
                    }
                ?>
            </table>
            <?php
                }
                else {
            ?>
            <div class="nobooks">Oops!! Looks like there are no such books what you have searched</div>
            <div class="nobooks">Try to search something else...</div>
            <?php
                }
            ?>
        </div>
    </div>
    <script src="../Essential Kits/js/Navbar.js"></script>
    <?php include 'suggestions.php'; ?>
    <script src="Searchbook-script.js"></script>
    <!-- <script src="https://kit.fontawesome.com/bef3bec8c1.js" crossorigin="anonymous"></script> -->
</body>

</html>